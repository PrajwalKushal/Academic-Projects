# Time-to-ExecStart Analyzer

This tool connects to a Linux system via SSH and analyzes the time interval
between a systemd service leaving the inactive state and the execution of its
ExecStart command during system boot.

## Requirements
- Python 3.8+
- SSH access to target system
- Target system must use systemd
- No system modifications required

## Usage

```bash
./time-to-execstart-analyzer.py <hostname> <ssh_key> [--out-file output.json]

## JSON Output Format

The tool outputs structured JSON suitable for further analysis or visualization.

```json
{
  "metadata": {
    "hostname": "string",
    "collected_at": "ISO-8601 UTC timestamp",
    "service_count": "integer"
  },
  "services": [
    {
      "unit": "string",
      "description": "string",
      "time_to_execstart_usec": "integer",
      "inactive_exit_usec": "integer",
      "execstart_usec": "integer",
      "active_enter_usec": "integer"
    }
  ]
}
